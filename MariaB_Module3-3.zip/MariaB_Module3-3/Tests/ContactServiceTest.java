package Tests;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Contact.Contact;
import Contact.ContactService;

class ContactServiceTest {

    @AfterEach
    void tearDown() throws Exception {
        // Clear the contact list after each test
        ContactService.contactList.clear();
    }

    @DisplayName("Test adding a unique contact")
    @Test
    void testAddUniqueContact() {
        // Arrange
        String firstName = "Greg";
        String lastName = "Hoffman";
        String phoneNumber = "1234567891";
        String address = "123 Main Street";

        ContactService test = new ContactService();

        // Act
        test.addContact(firstName, lastName, phoneNumber, address);

        // Assert
        assertAll("Verify added contact",
            () -> assertFalse(ContactService.contactList.isEmpty(), "Contact list should not be empty"),
            () -> assertEquals(firstName, ContactService.contactList.get(0).getFirstName(), "First name should match"),
            () -> assertEquals(lastName, ContactService.contactList.get(0).getLastName(), "Last name should match"),
            () -> assertEquals(phoneNumber, ContactService.contactList.get(0).getPhoneNumber(), "Phone number should match"),
            () -> assertEquals(address, ContactService.contactList.get(0).getAddress(), "Address should match")
        );
    }

    @DisplayName("Test deleting a contact")
    @Test
    void testDeleteContact() {
        // Arrange
        String firstName = "Greg";
        String lastName = "Hoffman";
        String phoneNumber = "1234567891";
        String address = "123 Main Street";

        ContactService test = new ContactService();
        test.addContact(firstName, lastName, phoneNumber, address);
        test.addContact(firstName, lastName, phoneNumber, address);
        test.addContact(firstName, lastName, phoneNumber, address);

        // Act
        test.deleteContact("1");

        // Assert
        assertNull(test.getContact("1"), "Contact with ID 1 should be deleted");
    }


    @DisplayName("Test editing a phone number")
    @Test
    void testEditPhone() {
        // Arrange
        String firstName = "Greg";
        String lastName = "Hoffman";
        String phoneNumber = "1234567891";
        String address = "123 Main Street";

        ContactService test = new ContactService();
        test.addContact(firstName, lastName, phoneNumber, address);

        // Act
        test.editNumber("0", "1987654321");

        // Assert
        Contact editedContact = test.getContact("0");
        assertNotNull(editedContact, "Edited contact should not be null");
        assertEquals("1987654321", editedContact.getPhoneNumber(), "Phone number should be updated");
    }


    @DisplayName("Test editing a last name")
    @Test
    void testEditLast() {
        // Arrange
        String firstName = "Greg";
        String lastName = "Hoffman";
        String phoneNumber = "1234567891";
        String address = "123 Main Street";

        ContactService test = new ContactService();
        test.addContact(firstName, lastName, phoneNumber, address);

        // Act
        test.editLastName("0", "Test_Name");

        // Assert
        Contact editedContact = test.getContact("0");
        assertNotNull(editedContact, "Edited contact should not be null");
        assertEquals("Test_Name", editedContact.getLastName(), "Last name should be updated");
    }

    @DisplayName("Test editing a first name")
    @Test
    void testEditFirst() {
        // Arrange
        String firstName = "Greg";
        String lastName = "Hoffman";
        String phoneNumber = "1234567891";
        String address = "123 Main Street";

        ContactService test = new ContactService();
        test.addContact(firstName, lastName, phoneNumber, address);

        // Act
        test.editFirstName("0", "Test_First");

        // Assert
        Contact editedContact = test.getContact("0");
        assertNotNull(editedContact, "Edited contact should not be null");
        assertEquals("Test_First", editedContact.getFirstName(), "First name should be updated");
    }


    @DisplayName("Test editing an address")
    @Test
    void testEditAddress() {
        // Arrange
        String firstName = "Greg";
        String lastName = "Hoffman";
        String phoneNumber = "1234567891";
        String address = "123 Main Street";

        ContactService test = new ContactService();
        test.addContact(firstName, lastName, phoneNumber, address);

        // Act
        test.editAddress("0", "Test_Address");

        // Assert
        Contact editedContact = test.getContact("0");
        assertNotNull(editedContact, "Edited contact should not be null");
        assertEquals("Test_Address", editedContact.getAddress(), "Address should be updated");
    }
}
